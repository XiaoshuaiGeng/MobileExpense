package com.example.project311;

public class DbStrings {

    static String ip = "remotemysql.com";
    static int port = 3306;
    //static String database = "hutubill";
    static String database = "1upG4O4v3S";
    static String encoding = "verifyServerCertificate=false&useSSL=false";
    static String loginName = "1upG4O4v3S";
    static String password = "dl71eRA0sD";
}
